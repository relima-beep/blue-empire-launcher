# Blue Empire Launcher

An initial Android home-screen launcher prototype with blue/gold styling and a list of installed apps, intended for Samsung Galaxy Z Flip7 FE.

## Build APK

Upload the **contents** of this ZIP to the root of the GitHub repository (not the enclosing folder), preserving paths including `.github/workflows/build-apk.yml`. On GitHub, open **Actions > Build Android APK**. After a successful run, download the artifact named `blue-empire-launcher-apk`, unzip it and install `app-debug.apk`.

You may need to allow installation from the app used to open the APK. To use it as your home screen, select Blue Empire Launcher in **Settings > Apps > Choose default apps > Home app**.

This is a first functional prototype, **not** a complete Samsung One UI theme. It does not replace lock screen, system icons, or cover-screen UI. A GitHub Actions build has not yet been verified.
