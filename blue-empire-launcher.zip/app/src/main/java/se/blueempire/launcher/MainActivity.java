package se.blueempire.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, apps;
    final int gold = Color.rgb(218,176,68);
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,36,24,16);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff06182f,0xff142d52,0xff050b17}));
        TextView title = new TextView(this);
        title.setText("BLUE EMPIRE");
        title.setTextColor(gold); title.setTextSize(30); title.setTypeface(null,Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("DIF  ×  ESCOBAR");
        subtitle.setTextColor(Color.WHITE); subtitle.setTextSize(15); subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);
        TextView clock = new TextView(this);
        clock.setTextColor(gold); clock.setTextSize(35); clock.setGravity(Gravity.CENTER);
        clock.setPadding(0,36,0,24);
        root.addView(clock);
        clock.setText(new java.text.SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()));
        Button all = new Button(this); all.setText("ALLA APPAR"); all.setOnClickListener(v->loadApps());
        root.addView(all);
        ScrollView scroll = new ScrollView(this);
        apps = new LinearLayout(this); apps.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(apps);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        loadApps();
    }
    void loadApps() {
        apps.removeAllViews();
        Intent query = new Intent(Intent.ACTION_MAIN); query.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = getPackageManager().queryIntentActivities(query,0);
        Collections.sort(list,new ResolveInfo.DisplayNameComparator(getPackageManager()));
        for (ResolveInfo item : list) {
            if (item.activityInfo.packageName.equals(getPackageName())) continue;
            TextView app = new TextView(this);
            app.setText(item.loadLabel(getPackageManager()));
            app.setTextColor(Color.WHITE); app.setTextSize(18); app.setPadding(14,18,14,18);
            app.setOnClickListener(v->{
                Intent launch = new Intent(Intent.ACTION_MAIN);
                launch.addCategory(Intent.CATEGORY_LAUNCHER);
                launch.setClassName(item.activityInfo.packageName,item.activityInfo.name);
                try { startActivity(launch); } catch(Exception e) { Toast.makeText(this,"Kunde inte öppna appen",Toast.LENGTH_SHORT).show(); }
            });
            apps.addView(app);
        }
    }
}
